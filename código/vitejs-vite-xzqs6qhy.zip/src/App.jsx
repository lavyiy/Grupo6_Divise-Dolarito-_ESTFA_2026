import React, { useState, useCallback, useRef } from 'react';
import './App.css';

import { useRates }   from './hooks/useRates';
import Header         from './components/Header/Header';
import Ticker         from './components/Ticker/Ticker';
import Footer         from './components/Footer/Footer';
import Modal          from './components/Modal/Modal';
import Toast          from './components/Toast/Toast';

import Cotizaciones   from './pages/Cotizaciones/Cotizaciones';
import Conversor      from './pages/Conversor/Conversor';
import Graficos       from './pages/Graficos/Graficos';
import Mercado        from './pages/Mercado/Mercado';

export default function App() {
  const rates                       = useRates(4000);
  const [activeTab, setActiveTab]   = useState('cotizaciones');
  const [modalOpen, setModalOpen]   = useState(false);
  const [toastMsg,  setToastMsg]    = useState('');
  const [toastVis,  setToastVis]    = useState(false);
  const toastTimer                  = useRef(null);

  // ── Toast helper ───────────────────────────────
  const toast = useCallback((msg) => {
    setToastMsg(msg);
    setToastVis(true);
    clearTimeout(toastTimer.current);
    toastTimer.current = setTimeout(() => setToastVis(false), 3000);
  }, []);

  // ── Alert save ─────────────────────────────────
  const handleSaveAlert = ({ divisa, condicion, valor, email }) => {
    setModalOpen(false);
    toast(`🔔 Alerta activada: ${divisa} — ${condicion} $${valor}`);
  };

  // ── Tab render ─────────────────────────────────
  const renderPage = () => {
    switch (activeTab) {
      case 'cotizaciones': return <Cotizaciones rates={rates} toast={toast} />;
      case 'conversor':    return <Conversor    rates={rates} toast={toast} />;
      case 'graficos':     return <Graficos     rates={rates} />;
      case 'mercado':      return <Mercado />;
      default:             return null;
    }
  };

  return (
    <div className="app">
      {/* ── Top bar ── */}
      <Header
        activeTab={activeTab}
        onTabChange={setActiveTab}
        onAlertClick={() => setModalOpen(true)}
      />

      {/* ── Live ticker ── */}
      <Ticker rates={rates} />

      {/* ── Page content ── */}
      <main className="app__main">
        {renderPage()}
      </main>

      {/* ── Footer ── */}
      <Footer />

      {/* ── Modal ── */}
      {modalOpen && (
        <Modal
          onClose={() => setModalOpen(false)}
          onSave={handleSaveAlert}
        />
      )}

      {/* ── Toast ── */}
      <Toast message={toastMsg} visible={toastVis} />
    </div>
  );
}
